<script setup>
import LifeJourneyPage from '../../components/LifeJourneyPage.vue';
</script>
<template><LifeJourneyPage page-id="238" /></template>

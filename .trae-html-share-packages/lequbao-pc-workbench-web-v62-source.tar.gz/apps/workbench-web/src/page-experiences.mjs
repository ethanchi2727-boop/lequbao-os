const experiences = [
  {
    page: 'page-003',
    layout: 'conversation-start',
    kicker: 'AI 对话 · 新任务',
    headline: '先说清要完成什么，再决定调用哪些能力',
    description: '从经营目标、期望成果和限制条件开始。系统不会仅凭一句话执行高风险动作。',
    panels: [
      ['任务目标', '描述希望解决的问题、对象和完成标准'],
      ['可信材料', '添加与任务直接相关的文件、链接或业务记录'],
      ['执行边界', '确认身份、租户、门店范围和需要人工确认的动作'],
    ],
    actions: [
      ['进入商户建档', 'page-014'],
      ['查看后台任务', 'page-010'],
    ],
    guardrail: '未建立权威会话前不读取业务数据，也不自动执行写操作。',
  },
  {
    page: 'page-004',
    layout: 'conversation-thread',
    kicker: 'AI 对话 · 持续会话',
    headline: '在同一条可追溯会话中继续经营任务',
    description: '对话、已确认事实、待办动作和成果版本保持关联，避免跨任务混用上下文。',
    panels: [
      ['已确认上下文', '只继承当前身份与当前会话确认过的事实'],
      ['本轮计划', '把用户目标拆成可撤回、可确认的动作'],
      ['成果与来源', '每项结论都能回到原材料、工具调用和确认记录'],
    ],
    actions: [
      ['开始新对话', 'page-003'],
      ['查看来源轨迹', 'page-007'],
    ],
    guardrail: '会话上下文不能替代实时权限检查和高风险二次确认。',
  },
  {
    page: 'page-005',
    layout: 'task-plan',
    kicker: 'AI 对话 · 复杂任务',
    headline: '把复杂任务拆成计划、依赖、确认点和可恢复步骤',
    description: '执行前展示任务结构；等待外部条件或人工确认时暂停，不伪装成已经完成。',
    panels: [
      ['任务范围', '明确输入、输出、排除项和完成标准'],
      ['步骤与依赖', '区分可并行步骤、前置条件和外部等待'],
      ['确认门', '发布、资金、权限和不可逆动作必须单独确认'],
      ['恢复点', '失败后从安全断点继续，不重复已成功副作用'],
    ],
    actions: [
      ['查看成果预览', 'page-006'],
      ['查看后台任务', 'page-010'],
    ],
    guardrail: '计划状态不等于业务状态，最终结果以权威系统回执为准。',
  },
  {
    page: 'page-006',
    layout: 'artifact-preview',
    kicker: 'AI 对话 · 成果预览',
    headline: '在交付前核对成果版本、差异、来源和发布影响',
    description: '预览只展示当前可见版本；需要写入或发布时进入明确确认流程。',
    panels: [
      ['版本摘要', '显示生成时间、输入范围和与上一版的差异'],
      ['成果正文', '按真实交付格式预览，不把占位符当成内容'],
      ['来源覆盖', '标出已引用、缺失和存在冲突的证据'],
      ['交付准备', '检查格式、权限、敏感信息和目标渠道'],
    ],
    actions: [
      ['查看来源轨迹', 'page-007'],
      ['返回复杂任务', 'page-005'],
    ],
    guardrail: '预览不会自动发布、下载敏感材料或覆盖既有正式版本。',
  },
  {
    page: 'page-007',
    layout: 'provenance-timeline',
    kicker: 'AI 对话 · 来源与工具轨迹',
    headline: '按时间查看每项结论来自哪里、调用了什么、由谁确认',
    description: '材料、工具调用、权限裁决和人工确认形成同一条可审计轨迹。',
    panels: [
      ['来源事件', '记录原始材料、业务记录和版本标识'],
      ['工具调用', '记录工具名称、输入范围、结果摘要和失败状态'],
      ['权限裁决', '记录租户、资源范围和拒绝原因，不展示秘密凭据'],
      ['人工确认', '记录确认对象、影响范围、操作者和追踪号'],
    ],
    actions: [
      ['查看成果预览', 'page-006'],
      ['查看原始材料', 'page-011'],
    ],
    guardrail: '审计轨迹只读；修正业务内容必须产生新版本而不是改写历史。',
  },
  {
    page: 'page-009',
    layout: 'session-inbox',
    kicker: 'AI 对话 · 会话列表',
    headline: '按责任范围处理会话，不把客户、商户和内部任务混在一起',
    description: '列表优先展示待处理、风险和等待时长；服务端决定可见会话范围。',
    panels: [
      ['待我处理', '展示当前身份有责任且尚未完成的会话'],
      ['等待对方', '区分等待客户、商户、内部审批或外部 provider'],
      ['风险标记', '突出敏感信息、投诉、资金和发布风险'],
      ['最近更新', '以服务端时间排序并保留未读位置'],
    ],
    actions: [
      ['打开普通对话', 'page-004'],
      ['开始新对话', 'page-003'],
    ],
    guardrail: '搜索和筛选不能扩大服务端授予的租户、门店或会话范围。',
  },
  {
    page: 'page-010',
    layout: 'job-queue',
    kicker: 'AI 对话 · 后台任务',
    headline: '区分运行、等待、失败和完成，不用进度动画掩盖停滞',
    description: '每个后台任务展示当前步骤、等待原因、最近心跳和安全恢复入口。',
    panels: [
      ['运行中', '显示当前步骤、最近心跳和预计的下一状态'],
      ['等待中', '明确等待人工、外部系统、配额还是计划时间'],
      ['可恢复失败', '保留已完成步骤、失败原因和安全重试入口'],
      ['已完成', '展示权威回执、成果版本和后续动作'],
    ],
    actions: [
      ['查看复杂任务', 'page-005'],
      ['查看成果预览', 'page-006'],
    ],
    guardrail: '停止或重试任务前必须确认是否已经产生不可重复的外部副作用。',
  },
  {
    page: 'page-011',
    layout: 'source-library',
    kicker: 'AI 对话 · 材料与来源',
    headline: '集中查看原始材料、扫描状态、关联任务和使用目的',
    description: '材料库不是公开网盘；下载、预览和复用都遵守最小权限与声明目的。',
    panels: [
      ['原始材料', '保留文件类型、大小、哈希、上传者和服务端对象标识'],
      ['安全状态', '区分扫描中、可用、隔离和已过期'],
      ['任务关联', '说明哪些会话、字段和成果引用了该材料'],
      ['来源链', '从派生内容回到原件，不覆盖原始证据'],
    ],
    actions: [
      ['查看工具轨迹', 'page-007'],
      ['进入材料与语音', 'page-015'],
    ],
    guardrail: '未通过安全扫描或超出声明目的的材料不可预览、下载或发送。',
  },
  {
    page: 'page-012',
    layout: 'identity-switcher',
    kicker: 'AI 对话 · 身份与空间',
    headline: '切换身份与工作空间前先看清权限差异和数据边界',
    description: '当前身份、租户、门店和角色范围必须持续可见；切换不会继承越权上下文。',
    panels: [
      ['当前身份', '展示认证主体、角色和会话有效期，不展示认证令牌'],
      ['当前空间', '展示租户、组织和门店范围'],
      ['权限差异', '切换前说明将获得和失去的能力'],
      ['上下文处理', '未发送草稿保留在本地内存，业务数据按新范围重新读取'],
    ],
    actions: [['返回新对话', 'page-003']],
    guardrail: '身份切换必须由服务端重新签发会话并重新裁决资源范围。',
  },
];

export const workbenchPageExperiences = Object.freeze(
  experiences.map((experience) =>
    Object.freeze({
      ...experience,
      panels: Object.freeze(experience.panels.map((panel) => Object.freeze(panel))),
      actions: Object.freeze(experience.actions.map((action) => Object.freeze(action))),
    }),
  ),
);

export const workbenchPageExperienceById = new Map(
  workbenchPageExperiences.map((experience) => [experience.page, experience]),
);

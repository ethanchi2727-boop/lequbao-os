import { createReadStream } from 'node:fs';
import { stat } from 'node:fs/promises';
import { createServer } from 'node:http';
import { extname, join, normalize, resolve, sep } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const defaultRoot = fileURLToPath(new URL('./src/', import.meta.url));
const defaultLifeAssetRoot = fileURLToPath(new URL('../../assets/miniapp/', import.meta.url));
const types = {
  '.css': 'text/css',
  '.js': 'text/javascript',
  '.mjs': 'text/javascript',
  '.svg': 'image/svg+xml',
  '.webp': 'image/webp',
};

const writeJson = (response, statusCode, body) => {
  const content = Buffer.from(JSON.stringify(body));
  response.writeHead(statusCode, {
    'content-type': 'application/json; charset=utf-8',
    'content-length': content.length,
    'cache-control': 'no-store',
  });
  response.end(content);
};

async function requestBody(request, maximumBytes = 64 * 1024 * 1024) {
  const chunks = [];
  let size = 0;
  for await (const chunk of request) {
    size += chunk.length;
    if (size > maximumBytes) throw new Error('development proxy body too large');
    chunks.push(chunk);
  }
  return Buffer.concat(chunks);
}

async function proxyRequest(request, response, apiBaseUrl, apiProxyToken, fetchImpl) {
  const requested = new URL(request.url ?? '/', 'http://development-workbench.local');
  const target = new URL(`${requested.pathname}${requested.search}`, apiBaseUrl);
  const headers = new Headers();
  for (const [name, value] of Object.entries(request.headers)) {
    if (
      !value ||
      [
        'connection',
        'content-length',
        'forwarded',
        'host',
        'transfer-encoding',
        'x-forwarded-for',
        'x-forwarded-host',
        'x-forwarded-proto',
        'x-real-ip',
      ].includes(name)
    )
      continue;
    headers.set(name, Array.isArray(value) ? value.join(', ') : value);
  }
  if (apiProxyToken) headers.set('authorization', `Bearer ${apiProxyToken}`);
  const method = request.method ?? 'GET';
  const body = method === 'GET' || method === 'HEAD' ? undefined : await requestBody(request);
  const upstream = await fetchImpl(target, { method, headers, ...(body ? { body } : {}) });
  response.statusCode = upstream.status;
  for (const [name, value] of upstream.headers) {
    if (['connection', 'content-encoding', 'content-length', 'transfer-encoding'].includes(name))
      continue;
    response.setHeader(name, value);
  }
  response.setHeader('cache-control', 'no-store');
  response.end(Buffer.from(await upstream.arrayBuffer()));
}

async function developmentLogin(response, options) {
  const { apiBaseUrl, apiProxyToken, fetchImpl = fetch } = options ?? {};
  let accessToken;
  if (apiBaseUrl) {
    // 优先走真实断言交换（契约测试起了 upstream mock server，会返回 deterministic token）
    const headers = {
      'content-type': 'application/json',
      'x-trace-id': 'development-mock-login',
    };
    if (apiProxyToken) headers.authorization = `Bearer ${apiProxyToken}`;
    const exchange = await fetchImpl(new URL('/api/v1/auth/sessions/exchange', apiBaseUrl), {
      method: 'POST',
      headers,
      body: JSON.stringify({
        provider: 'PHONE_OTP',
        assertion: 'development-mock-assertion-for-local-workspace',
        deviceId: 'development-mock-workbench-device',
      }),
    });
    if (!exchange.ok) {
      // 受控预览/本地 mock gateway 不可达时，退回 development-only 本地会话签发。
      // 生产禁止 LEQU_DEVELOPMENT_MOCKS=1，因此该路径仅在开发沙箱/受控预览中存在。
      accessToken =
        'development-mock-access-token-' +
        'a'.repeat(48) +
        '-' +
        Math.random().toString(36).slice(2, 10);
    } else {
      const result = await exchange.json();
      if (typeof result.accessToken !== 'string' || result.accessToken.length < 16)
        return writeJson(response, 502, { code: 'DEVELOPMENT_LOGIN_RESPONSE_INVALID' });
      accessToken = result.accessToken;
    }
  } else {
    // 没有 upstream 就纯本地签发
    accessToken =
      'development-mock-access-token-' +
      'a'.repeat(48) +
      '-' +
      Math.random().toString(36).slice(2, 10);
  }
  const token = JSON.stringify(accessToken).replaceAll('<', '\\u003c');
  const content = Buffer.from(`<!doctype html>
<html lang="zh-CN"><meta charset="utf-8"><title>开发一键登录</title>
<body><p>正在建立 development-mock 会话（手机一键登录·模拟断言）；该会话不可用于生产。</p>
<script>sessionStorage.setItem('lequbao.employee-session', ${token});location.replace('/bao/page-014');</script>
</body></html>`);
  response.writeHead(200, {
    'content-type': 'text/html; charset=utf-8',
    'content-length': content.length,
    'cache-control': 'no-store',
    'x-lequ-data-source': 'development-mock',
  });
  response.end(content);
}

export function createWorkbenchDevelopmentServer({
  root = defaultRoot,
  lifeAssetRoot = defaultLifeAssetRoot,
  lifeRoot,
  baoMobileRoot,
  apiBaseUrl,
  apiProxyToken,
  developmentMock = false,
  publicPreview = false,
  publicHostname,
  fetchImpl = fetch,
} = {}) {
  return createServer(async (request, response) => {
    try {
      const url = new URL(request.url ?? '/', 'http://local');
      if (publicPreview) {
        response.setHeader('x-robots-tag', 'noindex, nofollow, noarchive');
        response.setHeader('x-content-type-options', 'nosniff');
        response.setHeader('x-frame-options', 'DENY');
        response.setHeader('referrer-policy', 'no-referrer');
        response.setHeader('x-lequ-environment', 'development-mock-preview');
      }
      if (request.method === 'GET' && url.pathname === '/health')
        return writeJson(response, 200, { status: 'ok', version: '6.1.0-development' });
      if (publicPreview && publicHostname) {
        const requestHostname = (request.headers.host ?? '').split(':')[0]?.toLowerCase();
        if (requestHostname !== publicHostname.toLowerCase())
          return writeJson(response, 421, { code: 'PREVIEW_HOST_MISMATCH' });
      }
      if (publicPreview && developmentMock && request.method === 'GET' && url.pathname === '/') {
        response.statusCode = 302;
        response.setHeader('location', '/__development/login');
        return response.end();
      }
      if (
        publicPreview &&
        developmentMock &&
        request.method === 'GET' &&
        ['/bao', '/bao/'].includes(url.pathname)
      ) {
        response.statusCode = 302;
        response.setHeader('location', '/__development/login');
        return response.end();
      }
      if (url.pathname === '/__development/login') {
        if (!developmentMock || !apiBaseUrl) return writeJson(response, 404, { code: 'NOT_FOUND' });
        if (request.method !== 'GET')
          return writeJson(response, 405, { code: 'METHOD_NOT_ALLOWED' });
        return await developmentLogin(response, { apiBaseUrl, apiProxyToken, fetchImpl });
      }
      if (apiBaseUrl && (url.pathname.startsWith('/api/') || url.pathname.startsWith('/internal/')))
        return await proxyRequest(request, response, apiBaseUrl, apiProxyToken, fetchImpl);

      const requested = decodeURIComponent(url.pathname);
      const assetPrefix = '/life-assets/';
      const assetName = requested.startsWith(assetPrefix)
        ? requested.slice(assetPrefix.length)
        : '';
      const allowedLifeAssets = new Set([
        'life-banner.webp',
        'life-category-sprite.webp',
        'life-product.webp',
        'local-dining.webp',
      ]);
      const lifeRequest = requested === '/life' || requested.startsWith('/life/');
      const baoMobileRequest = requested === '/bao-mobile' || requested.startsWith('/bao-mobile/');
      const surface =
        lifeRequest && lifeRoot
          ? { root: resolve(lifeRoot), prefix: '/life' }
          : baoMobileRequest && baoMobileRoot
            ? { root: resolve(baoMobileRoot), prefix: '/bao-mobile' }
            : null;
      const surfacePath = surface ? requested.slice(surface.prefix.length) || '/' : requested;
      const candidate = assetName
        ? normalize(join(lifeAssetRoot, assetName))
        : normalize(join(surface?.root ?? root, surfacePath));
      const candidateRoot = surface?.root ?? root;
      let file =
        assetName && allowedLifeAssets.has(assetName) && candidate.startsWith(lifeAssetRoot)
          ? candidate
          : candidate === candidateRoot || candidate.startsWith(`${candidateRoot}${sep}`)
            ? candidate
            : join(root, lifeRequest ? 'life.html' : 'index.html');
      try {
        if ((await stat(file)).isDirectory()) file = join(file, 'index.html');
      } catch {
        file = join(
          surface?.root ?? root,
          surface ? 'index.html' : lifeRequest ? 'life.html' : 'index.html',
        );
      }
      response.setHeader('content-type', types[extname(file)] ?? 'text/html; charset=utf-8');
      response.setHeader('cache-control', 'no-store');
      createReadStream(file).pipe(response);
    } catch (error) {
      writeJson(response, 502, {
        code: 'DEVELOPMENT_SERVER_ERROR',
        summary: error instanceof Error ? error.message : 'unknown error',
      });
    }
  });
}

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  const server = createWorkbenchDevelopmentServer({
    apiBaseUrl: process.env.WORKBENCH_API_PROXY_URL,
    apiProxyToken: process.env.WORKBENCH_API_PROXY_TOKEN,
    developmentMock: process.env.LEQU_DEVELOPMENT_MOCKS === '1',
    publicPreview: process.env.LEQU_PUBLIC_PREVIEW === '1',
    publicHostname: process.env.LEQU_PREVIEW_HOSTNAME,
    lifeRoot: process.env.LIFE_STATIC_ROOT,
    baoMobileRoot: process.env.BAO_MOBILE_STATIC_ROOT,
  });
  const port = Number(process.env.PORT ?? 4173);
  server.listen(port, process.env.HOST ?? '127.0.0.1', () => {
    const entry =
      process.env.LEQU_DEVELOPMENT_MOCKS === '1' ? '/__development/login' : '/bao/page-014?demo=1';
    console.log(`乐趣宝 Web preview: http://127.0.0.1:${port}${entry}`);
  });
}
